# api/routes/__init__.py
# This file makes the api/routes directory a Python package
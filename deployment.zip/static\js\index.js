// index.js - Specific functionality for the index page
console.log('Index page loaded');